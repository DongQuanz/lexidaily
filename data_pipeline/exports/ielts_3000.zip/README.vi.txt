IELTS 3000 — dữ liệu từ vựng Anh–Việt

Mở ielts_3000.jsonl bằng công cụ hỗ trợ JSON Lines và UTF-8. Mỗi dòng là một mục.
Bộ gồm 3.000 mục từ/cụm từ, một từ loại và một nghĩa học chính cho mỗi mục.
Mục tiêu người học: IELTS 6.5–8.5. Không gán band cho từng từ.
Nhãn CEFR là tham chiếu headword/POS từ CEFR-J/Octanove hoặc ước tính biên tập.
Có 798 mục có ví dụ, 514 mục có collocation và 2812 mục có IPA.
Trường nội dung bổ sung còn thiếu được để trống. Các mục nhập chưa được chuyên gia duyệt toàn bộ.
recommendedSkills là gợi ý chương trình học, không phải bằng chứng xuất hiện trong đề thi.
Xem quality_report.json để biết độ phủ, và licenses/ATTRIBUTION.txt để xem nguồn, giấy phép, thay đổi.
Dữ liệu được cung cấp theo CC BY-SA 4.0; giữ ghi công khi phân phối lại.
